package com.cayxu.app.ui.screens.friends

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.navigation.NavController
import com.cayxu.app.ui.theme.AppBackground
import com.cayxu.app.ui.theme.TextSecondary

@Composable
fun FriendsScreen(navController: NavController) {
    Box(Modifier.fillMaxSize().background(AppBackground), contentAlignment = Alignment.Center) {
        Text("Bạn bè / Giới thiệu (đang phát triển)", color = TextSecondary)
    }
}
